import RootLayout from "./components/RootLayout";
import DashboardHome from "./components/DashboardHome";
import TicketsLayout from "./components/TicketsLayout";
import TicketsList from "./components/TicketsList";
import TicketDetail from "./components/TicketDetail";
import TicketDetailInfo from "./components/TicketDetailInfo";
import TicketActivity from "./components/TicketActivity";
import SettingsLayout from "./components/SettingsLayout";
import ProfileSettings from "./components/ProfileSettings";
import NotificationSettings from "./components/NotificationSettings";
import NotFound from "./components/NotFound";

function App() {
  return (
    <RootLayout>
      {/* trainees: set up your routes here */}
    </RootLayout>
  );
}

export default App;
