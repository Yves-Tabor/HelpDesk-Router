function SettingsLayout() {
  return (
    <div className="settings-layout">
      <div className="page-header">
        <h2>Settings</h2>
        <p className="page-subtitle">Manage your account preferences</p>
      </div>

      <div className="settings-container">
        <div className="settings-sidebar">
          {/* trainees: convert these to proper navigation with active styling */}
          <div className="settings-tab active">Profile</div>
          <div className="settings-tab">Notifications</div>
        </div>

        <div className="settings-content">
          {/* trainees: Outlet goes here */}
        </div>
      </div>
    </div>
  );
}

export default SettingsLayout;
