function RootLayout({ children }) {
  return (
    <div className="root-layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <span className="logo-icon">⬡</span>
          <h1>HelpDesk</h1>
        </div>

        <nav className="sidebar-nav">
          {/* trainees: convert these to proper navigation */}
          <a href="/" className="nav-item">
            <span className="nav-icon">▦</span>
            Dashboard
          </a>
          <a href="/tickets" className="nav-item">
            <span className="nav-icon">🎫</span>
            Tickets
          </a>
          <a href="/settings" className="nav-item">
            <span className="nav-icon">⚙</span>
            Settings
          </a>
        </nav>

        <div className="sidebar-footer">
          <div className="user-badge">
            <div className="user-avatar">JD</div>
            <div className="user-info">
              <span className="user-name">Jane Doe</span>
              <span className="user-role">Support Lead</span>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content">
        {children}
        {/* trainees: you'll eventually replace {children} with an Outlet */}
      </main>
    </div>
  );
}

export default RootLayout;
